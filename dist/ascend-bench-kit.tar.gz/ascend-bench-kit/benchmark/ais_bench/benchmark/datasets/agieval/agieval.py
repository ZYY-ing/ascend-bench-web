import json
import os.path as osp
from os import environ

from datasets import Dataset

from ais_bench.benchmark.openicl.icl_evaluator import BaseEvaluator
from ais_bench.benchmark.registry import ICL_EVALUATORS, LOAD_DATASET
from ais_bench.benchmark.datasets.utils.datasets import get_data_path
from ais_bench.benchmark.utils.logging.logger import AISLogger
from ais_bench.benchmark.utils.logging.error_codes import DSET_CODES
from ais_bench.benchmark.utils.logging.exceptions import ParameterValueError, AISBenchDataContentError

from ..base import BaseDataset
from .math_equivalence import is_equiv
from .post_process import parse_math_answer

logger = AISLogger()


@LOAD_DATASET.register_module()
class AGIEvalDataset(BaseDataset):

    @staticmethod
    def load(path: str, name: str, setting_name: str):
        path = get_data_path(path)
        logger.debug(f"Loading AGIEval dataset '{name}' with setting '{setting_name}' from: {path}")
        from .dataset_loader import load_dataset, load_dataset_as_result_schema

        if setting_name != 'zero-shot':
            raise ParameterValueError(
                DSET_CODES.INVALID_PARAM_VALUE,
                f"AGIEval only supports 'zero-shot' setting, got '{setting_name}'"
            )
        dataset_wo_label = load_dataset(name, setting_name, path)
        dataset_with_label = load_dataset_as_result_schema(name, path)
        dataset = []
        for d1, d2 in zip(dataset_wo_label, dataset_with_label):
            dataset.append({
                'id': d2.index,
                'problem_input': d1['context'],
                'label': d2.label,
            })
        dataset = Dataset.from_list(dataset)
        logger.debug(f"AGIEval dataset '{name}' loaded: {len(dataset)} samples")
        return dataset


@LOAD_DATASET.register_module()
class AGIEvalDataset_v2(BaseDataset):

    @staticmethod
    def load(path: str, name: str, setting_name: str):
        path = get_data_path(path)
        
        if setting_name != 'zero-shot':
            raise ParameterValueError(
                DSET_CODES.INVALID_PARAM_VALUE,
                f"AGIEval_v2 only supports 'zero-shot' setting, got '{setting_name}'"
            )

        if environ.get('DATASET_SOURCE') == 'ModelScope':
            from modelscope import MsDataset
            ms_dataset = MsDataset.load(path, subset_name=name, split='test')
            dataset = []
            for item in ms_dataset:
                passage = item['passage'] if item['passage'] else ''
                question = passage + item['question']
                options = '\n'.join(item['options']) if item['options'] else ''
                if item['label']:
                    try:
                        label = eval(item['label'])
                    except Exception as e:
                        logger.debug(f"Failed to eval label, using as is: {e}")
                        label = item['label']
                    if isinstance(label, list):
                        label = ''.join(label)
                else:
                    label = item['answer']
                d = {'question': question, 'options': options, 'label': label}
                dataset.append(d)
            dataset = Dataset.from_list(dataset)
        else:
            filename = osp.join(path, name + '.jsonl')
            with open(filename, encoding='utf-8') as f:
                data = [json.loads(line.strip()) for line in f]
            dataset = []
            for item in data:
                passage = item['passage'] if item['passage'] else ''
                question = passage + item['question']
                options = '\n'.join(item['options']) if item['options'] else ''
                if item['label']:
                    if isinstance(item['label'], list):
                        label = ''.join(item['label'])
                    else:
                        label = item['label']
                else:
                    label = item['answer']
                d = {'question': question, 'options': options, 'label': label}
                dataset.append(d)
            dataset = Dataset.from_list(dataset)
        return dataset


@ICL_EVALUATORS.register_module()
class AGIEvalEvaluator(BaseEvaluator):

    def score(self, predictions, references):
        logger.debug(f"Starting AGIEval evaluation with {len(predictions)} samples")
        predictions = [parse_math_answer('', pred) for pred in predictions]
        details = []
        cnt = 0
        for pred, ref in zip(predictions, references):
            detail = {'pred': pred, 'answer': ref, 'correct': False}
            if is_equiv(pred, ref):
                cnt += 1
                detail['correct'] = True
            details.append(detail)
        score = cnt / len(predictions) * 100
        logger.debug(f"AGIEval evaluation completed: Score = {score:.2f}% ({cnt}/{len(predictions)})")
        return {'score': score, 'details': details}


@ICL_EVALUATORS.register_module()
class AGIEvalEvaluator_mcq(BaseEvaluator):

    def score(self, predictions, references):
        if len(predictions) != len(references):
            logger.debug(f"Predictions and references have different length: {len(predictions)} vs {len(references)}")
            return {
                'error': 'predictions and references have different '
                'length'
            }
        logger.debug(f"Starting AGIEval MCQ evaluation with {len(predictions)} samples")
        details = []
        cnt = 0
        for pred, ref in zip(predictions, references):
            detail = {'pred': pred, 'answer': ref, 'correct': False}
            if pred == ref:
                cnt += 1
                detail['correct'] = True
            details.append(detail)

        score = cnt / len(predictions) * 100
        logger.debug(f"AGIEval MCQ evaluation completed: Score = {score:.2f}% ({cnt}/{len(predictions)})")

        return {'score': score, 'details': details}
